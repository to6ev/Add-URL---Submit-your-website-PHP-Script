<?php
define("POSTURL","Add Your URL");
define("HOME","URLs");
define("VIEWS","Views");
define("POSTBY","Posted");
define("ON","on");
define("RECENT","recent");
define("POPULAR","popular");
define("ALL","all");
define("SEEYOURURL","See your URL");
define("EMPTYFIELD","ERROR: Input missing! Do not leave blank!");
define("URLADD","URL added!");
define("THANX","Thank You!");
define("SUBMIT","Submit");
define("CATEGORY","Category");
define("URL","http://");
define("SEARCH","Search...");
define("TIME","Date/time");
define("CHOOSELANG","Language");
define("ADMIN",".::Administration area::.");
define("NICKNAME","");
define("PASS","");
define("DELETE","Delete");
define("ALLURL","All URLs");
define("LOGOUT","Logout");
define("URLIST","URLs list");
define("HELLO","Hello");
define("WELCOME","Welcome to your admin area!");
?>
