<?php include'header.php'; ?>

<table width="100%" align="center" border="0" align="center" cellpadding="0" cellspacing="1" >
<tr>
<td><table width="100%" border="0" cellpadding="3" cellspacing="1" bordercolor="1" bgcolor="#FFFFFF">
<tr>
<td bgcolor="#FFFFFF">
<form name="form1" method="get" action="add">
<center>
<strong>URL Submit Free</strong><br /><strong><?php echo POSTURL; ?></strong><br />
<strong><?php echo URL; ?></strong>
<input name="url" type="text" maxlength="63" size="50" placeholder="your website here" onKeyPress="return charLimit(this)" onKeyUp="return characterCount(this)"> <strong><span id="charCount"> 63</span></strong> allowable symbols for domain
<!--
<input type="hidden" type="text"><br />
<br />
<img src="captcha.php" title="ETI Simple Captcha Code"/><br />
<input name="captcha" type="text" size="6" maxlength="4" title="Enter this digits, please. It's simple captcha code:)">
-->
<br />
<br />
<input type="submit" class="btn" style="cursor:pointer" value="<?php echo SUBMIT; ?>" />
<br /><br><p>Submit your website - It's 100% FREE</p>
<br />
Please do not abuse! Do not attempt to insert malicious code, no flood please:) Thank you!<br />
</center>
</td>
</tr>
</table>
</td>
</tr>
</table>

<?php
include 'footer.php';
?>
