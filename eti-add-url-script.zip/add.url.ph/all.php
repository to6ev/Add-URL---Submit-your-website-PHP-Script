<?php include 'header.php';?>
<?php echo URLIST; ?>
<br />
<table width="100%">
<br />
<?php 

function clean_url($rows){
	//return str_replace(array('http://','https://','www.'),'',$rows);
	return str_replace(array('http://','https://'),'',$rows);
}

$sql = 'SELECT * FROM links';
$result=mysql_query($sql);

while ($link=mysql_fetch_array($result)){
echo '<tr>
<td><a href="http://'.htmlspecialchars(clean_url($link['detail'])).'" target="_blank">'.$link['detail'].'</a></td>
      </tr>';
}
?>
</table>

<?php
include 'footer.php';
?>
