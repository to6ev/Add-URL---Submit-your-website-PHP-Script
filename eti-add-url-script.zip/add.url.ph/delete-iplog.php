<?php
$path="iplog.txt";
if(unlink($path)) echo "it's done!";
?>
