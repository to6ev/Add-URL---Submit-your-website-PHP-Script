<?php
include 'header.php';
?>

You can delete this page:)

<div>
<br />
<center>
<p><a href="http://eti.bl.ee" target="_blank">ETI</a> <?php echo date("Y") ; ?></p>
</center>
</div>

</body>
</html>
