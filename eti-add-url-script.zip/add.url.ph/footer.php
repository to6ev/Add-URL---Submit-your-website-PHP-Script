<div>
<br />
<center>
<a href="download" title="Source Code of this KISS PHP project">Get Source Code</a>
<br />
<p><a href="http://eti.free.bg" target="_blank">ETI</a> <?php echo date("Y") ; ?></p>
</center>
</div>

</body>
</html>
