<?php include 'header.php';?>
<table width="100%">
	<tr>
		<td><b><u><?php echo URLIST; ?></u></b></td>
	</tr>
	<tr>
		<table width="100%">
<?php 

function clean_url($rows){
	return str_replace(array('http://','https://'),'',$rows);
}

$act = $_GET['act'];
$id = $_GET['id'];

switch($act)
	{
	case 'delete';
$del='DELETE FROM links WHERE id='.$id.'';
$res=mysql_query($del)or die('Error SQL !'.$del.'<br>'.mysql_error());
break;
}
$sql = 'SELECT * FROM links ORDER BY id DESC';
// $sql = 'SELECT * FROM links';
$result=mysql_query($sql);

while ($link=mysql_fetch_array($result)){
echo '<tr>  
<td><a href="http://'.htmlspecialchars(clean_url($link['detail'])).'" target="_blank">'.$link['detail'].'</a> - &nbsp;<a href="links.php?act=delete&id='.$link['id'].'"><font color="red">'.DELETE.'</font></a></td>
      </tr>';
}
?>
</table>
<a name="bottom">
