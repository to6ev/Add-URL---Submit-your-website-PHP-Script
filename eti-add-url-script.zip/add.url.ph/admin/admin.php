<?php include 'header.php';?>
<?php echo HELLO; ?> <?php echo htmlentities(trim($_SESSION['login'])); ?>! <?php echo WELCOME; ?><br />
<?php include 'footer.php';?>
