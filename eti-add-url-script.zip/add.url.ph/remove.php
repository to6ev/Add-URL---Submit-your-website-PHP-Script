<?php
include 'header.php';
?>

How to remove your URL from our directory?<br><br>
If for any reason you want to remove your URL from add.url.ph you reached the right place.<br>
It's not so quite easy and fast:) You must write letter to us!<br>
Go to this website: <a href="http://tools.eti.pw/contact.php" target="_blank">www.tools.eti.pw/contact.php</a><br>
<br />

<?php
include 'footer.php';
?>
