<?php
$del = fopen ("log.html", "w+");
fclose($del);
echo "it's done!";
?>
